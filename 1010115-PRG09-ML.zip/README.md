# CMTPRG01-9 Machine Learning

Startercode in Python voor de opdracht Machine Learning.

Lees de lesbrief voor verdere instructies.
